import sounddevice as sd
from scipy.io.wavfile import write
from pydub import AudioSegment
import os
def record_audio(duration=5, sample_rate=44100):
    print("Recording...")
    recording = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=2)
    sd.wait()  # Wait until recording is finished
    output_filename = "output.wav"
    write(output_filename, sample_rate, recording)  # Save as WAV file
    print("Recording finished and saved to", output_filename)
    return output_filename

def convert_to_mp3(wav_filename, mp3_filename="output.mp3"):
    audio = AudioSegment.from_wav(wav_filename)
    audio.export(mp3_filename, format="mp3")  # Export as MP3
    print(f"Converted {wav_filename} to {mp3_filename}")

def record_and_save_mp3():
    wav_filename = record_audio()  # Record audio and get WAV filename
    mp=convert_to_mp3(wav_filename)  # Convert WAV to MP3
    return mp
# Call the function to start recording and saving as MP3
record_and_save_mp3()

# First, ensure that Whisper and ffmpeg are installed in your environment:
# !pip install git+https://github.com/openai/whisper
# !sudo apt update && sudo apt install ffmpeg

import whisper

def audio_to_text(audio_path):
    # Load the Whisper model
    model = whisper.load_model("medium.en")

    # Process the audio file
    result = model.transcribe(audio_path)

    # Return the transcription text
    return result['text']

# Example usage:
# text = audio_to_text("/content/output.mp3")
# print(text)
import google.generativeai as genai
def gemini(message):
    context="You are a top-tier algorithm designed for extracting information in structured formats to build a knowledge graph."
    genai.configure(api_key='AIzaSyC7hyOeVchYMmdd7dAq6lZ1eFS3s28sUeM')
    reply = genai.chat(context=context, messages=message)
    modified_reply=reply.last
    return modified_reply
